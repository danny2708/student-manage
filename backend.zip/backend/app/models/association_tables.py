"backend.app.models.association_tables"
from datetime import date
from sqlalchemy import Table, Column, Integer, ForeignKey, Enum, Date, String
from sqlalchemy.orm import relationship
from app.database import Base
import enum

# Bảng liên kết nhiều-nhiều giữa User và Role
user_roles = Table(
    "user_roles",
    Base.metadata,
    Column("user_id", Integer, ForeignKey("users.user_id"), primary_key=True),
    Column("role_id", Integer, ForeignKey("roles.role_id"), primary_key=True),
)

# Nếu bạn có các bảng liên kết khác (student-parent, student-class), giữ nguyên dạng class
# nhưng cần dùng cùng Base từ app.database (không tạo declarative_base mới).

class StudentParentAssociation(Base):
    __tablename__ = 'student_parents'

    student_id = Column(Integer, ForeignKey('students.student_id'), primary_key=True)
    parent_id = Column(Integer, ForeignKey('parents.parent_id'), primary_key=True)

    student = relationship("Student", back_populates="student_parent_associations")
    parent = relationship("Parent", back_populates="student_parent_associations")


class EnrollmentStatus(enum.Enum):
    Active = "Active"
    OnLeave = "OnLeave"
    Transferred = "Transferred"
    Graduated = "Graduated"


class StudentClassAssociation(Base):
    __tablename__ = 'student_class'

    student_id = Column(Integer, ForeignKey('students.student_id'), primary_key=True)
    class_id = Column(Integer, ForeignKey('classes.class_id'), primary_key=True)
    enrollment_date = Column(Date, default=date.today(), nullable=False)
    status = Column(Enum(EnrollmentStatus), nullable=False, default=EnrollmentStatus.Active)

    student = relationship("Student", back_populates="student_class_associations")
    class_ = relationship("Class", back_populates="student_class_associations")